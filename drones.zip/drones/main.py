from formation import *


five(34, 24, 5)

print(globals())
