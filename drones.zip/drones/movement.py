import time
from drone import Drone

def move(direction: str, distance: int):
    if direction == 'x':
        counter = 0
        while counter < distance:
            for drone in Drone.all:
                x_current = drone.get_x
                y_current = drone.get_y
                drone.set_cordinate(x_current + counter, y_current)
            counter = counter + 1
            time.sleep(1)
    elif direction == 'y':
        counter = 0
        while counter < distance:
            for drone in Drone.all:
                x_current = drone.get_x
                y_current = drone.get_y
                drone.set_cordinate(x_current, y_current + counter)
            counter = counter + 1
            time.sleep(1)



move('x', 20)

print(drone1.cordinate)
print(drone2.cordinate)
print(drone3.cordinate)
print(drone4.cordinate)
print(drone5.cordinate)