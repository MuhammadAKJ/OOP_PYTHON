MAX_X = 1366
MAX_Y = 768
class Drone:
    """This a drone class"""
    repr = []
    all = []
    

    def __init__(self, name: str, x_cor: int, y_cor: int):
        # Assertion for evaluating validity of cordinates
        assert x_cor >= 0 and x_cor < MAX_X, f"x cordinate value must be e E (0,{MAX_X})"
        assert y_cor >= 0 and y_cor < MAX_Y, f"y cordinate value must be e E (0,{MAX_Y})"
        
        # Assigning variables
        self.__name = name
        self.__xcor = x_cor
        self.__ycor = y_cor

        # Append item to all
        Drone.all.append(self)

    @property
    def cordinate(self):
        return f"({self.__xcor}, {self.__ycor})"
    
    @property
    def get_x(self):
        return self.__xcor
    
    def get_y(self):
        return self.__ycor
    
    @cordinate.setter
    def set_cordinate(self, x_value: int, y_value):
        if x_value < 0 or x_value > MAX_X:
            raise ValueError(f"x cordinate value must be e E (0,{MAX_X})")
        if y_value < 0 or y_value > MAX_Y:
            raise ValueError(f"y cordinate value must be e E (0,{MAX_Y})")
       
        self.__xcor = x_value
        self.__ycor = y_value
        print('\nnew cordinates')
        self.cordinate()


    def __repr__(self):
        return f"Drone({self.__name}, {self.__xcor}, {self.__ycor})"
    
    def __str__(self):
        return f"{self.__name}"