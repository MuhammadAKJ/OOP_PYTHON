"""Flight formation"""
from drone import Drone


def one(x: int, y: int):
    """create one drone"""
    Drone('drone1', x, y)
    print('Drone successfully created')
    return True

def two(x: int, y: int, spacing: int):
    """Create two drone formations"""
    cordinates = [(x,y), (x, y+spacing)]
    loop(cordinates=cordinates)

def three(x: int, y: int, spacing: int):
    """Create three drone formation"""
    cordinates = [(x,y), (x-spacing, y+spacing), (x+spacing, y+spacing)]
    loop(cordinates=cordinates)

def four(x: int, y: int, spacing: int):
    """Create four drone formations"""
    cordinates = [(x,y), (x, y+spacing), (x+spacing, y), (x+spacing, y+spacing)]
    loop(cordinates=cordinates)

def five(x: int, y: int, spacing: int):
    """Create five drone formation"""
    cordinates = [(x,y), (x, y+spacing), (x, y-spacing), (x+spacing, y), (x-spacing, y)]
    loop(cordinates=cordinates)
    

def six(x: int, y: int, spacing: int):
    """Create six drone formation"""
    cordinates = [(x,y), (x, y-spacing), (x-spacing,y), (x+spacing,y), (x-(0.5*spacing), y+spacing), (x+(0.5*spacing), y+spacing)]
    loop(cordinates=cordinates)


def loop(cordinates):
    """Function to loop through cordinates and create drone formations"""
    for item in cordinates:
        x_cor, y_cor = item
        Drone(f'drone{cordinates.index(item)}', x_cor, y_cor)
    print(Drone.all)
