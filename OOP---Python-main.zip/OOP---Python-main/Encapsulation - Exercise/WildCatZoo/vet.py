from WildCatZoo.worker import Worker


class Vet(Worker):
    pass
