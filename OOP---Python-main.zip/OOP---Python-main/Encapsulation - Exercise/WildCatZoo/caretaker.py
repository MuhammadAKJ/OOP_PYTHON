from WildCatZoo.worker import Worker


class Caretaker(Worker):
    pass
