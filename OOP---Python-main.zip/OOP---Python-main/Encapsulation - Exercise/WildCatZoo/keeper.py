from WildCatZoo.worker import Worker


class Keeper(Worker):
    pass
