from NeedForSpeed.motorcycle import Motorcycle


class CrossMotorcycle(Motorcycle):
    pass
