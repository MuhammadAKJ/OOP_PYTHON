from NeedForSpeed.vehicle import Vehicle


class Motorcycle(Vehicle):
    pass